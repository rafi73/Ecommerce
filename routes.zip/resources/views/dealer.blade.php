@extends('frontend')
@section('content')

@include('partials.breadcrumb', ['pageName' => 'Become a Dealer'])

<!-- checkout area start -->
<div class="checkout-area mt-40">
    <div class="container">
        <div class="row">
           
        </div>
    </div>
</div>
<!-- checkout area end -->
@endsection