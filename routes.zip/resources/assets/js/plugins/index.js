import './axios'
import './validation'
import i18n from './vue-i18n'

export { i18n }
