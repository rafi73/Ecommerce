<!-- scroll item menu start -->
<div class="scroll-item">
    <nav class="collapse navbar-collapse">
        <ul>
            <li><a href="#electronics" class="smooth"><img src="<?php echo e(asset('themes/frontend/img/icon/icon_electronics.jpg')); ?>"
                        alt=""></a></li>
            <li><a href="#fashion" class="smooth"><img src="<?php echo e(asset('themes/frontend/img/icon/icon_fashion.jpg')); ?>"
                        alt=""></a></li>
            <li><a href="#furniture" class="smooth"><img src="<?php echo e(asset('themes/frontend/img/icon/icon_Furniture.jpg')); ?>"
                        alt=""></a></li>
            <li><a href="#accessories" class="smooth"><img src="<?php echo e(asset('themes/frontend/img/icon/icon_sunglass.jpg')); ?>"
                        alt=""></a></li>
            <li id="scrollUp"> <a href="#"><i class="fa fa-angle-double-up"></i><span>back to top</span></a></li>
        </ul>
    </nav>
</div>
<!-- scroll item menu end -->