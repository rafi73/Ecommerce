<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.breadcrumb', ['pageName' => 'Become a Dealer'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- checkout area start -->
<div class="checkout-area mt-40">
    <div class="container">
        <div class="row">
           
        </div>
    </div>
</div>
<!-- checkout area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>