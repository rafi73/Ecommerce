<!-- breadcrumb area start -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(URL::route('home')); ?>"><i class="fa fa-home"></i></a></li>
                    <li class="active"><?php echo e($pageName); ?></li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb area end -->