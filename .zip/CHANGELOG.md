# Changelog

## 0.1.0 - 2017-10-17

- Initial release

## 1.0.0 - 2018-03-27

- Laravel 5.6 + Vuetify 1.0
