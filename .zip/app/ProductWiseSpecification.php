<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductWiseSpecification extends Model
{
    //
}
