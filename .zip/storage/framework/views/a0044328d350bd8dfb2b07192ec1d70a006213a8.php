<!-- slide show area start -->
<div class="slide-show">
    <!-- slider area start -->
    <div class="slider-area">
        <div class="bend niceties preview-1">
            <!-- slider images start -->
            <div id="nivoslider" class="slides">
                <img src="<?php echo e(asset('img/8.jpg')); ?>" alt="slider_1" />
                <img src="<?php echo e(asset('img/6.png')); ?>" alt="slider_1" />
                <img src="<?php echo e(asset('img/5.png')); ?>" alt="slider_1" />
                <img src="<?php echo e(asset('img/3.jpg')); ?>" alt="slider_1" />
            </div>
            <!-- slider images end -->
        </div>
    </div>
    <!-- slider area end -->
</div>
<!-- slide show area end -->