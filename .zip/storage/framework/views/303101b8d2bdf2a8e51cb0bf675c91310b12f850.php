
<?php
$config = [
    'appName' => config('app.name'),
    'locale' => $locale = app()->getLocale(),
    'translations' => json_decode(file_get_contents(resource_path("lang/{$locale}.json")), true),
];
?>
<script>window.config = <?php echo json_encode($config);; ?>;</script>


<?php
$polyfills = [
    'Promise',
    'Object.assign',
    'Object.values',
    'Array.prototype.find',
    'Array.prototype.findIndex',
    'Array.prototype.includes',
    'String.prototype.includes',
    'String.prototype.startsWith',
    'String.prototype.endsWith',
];
?>
<script src="https://cdn.polyfill.io/v2/polyfill.min.js?features=<?php echo e(implode(',', $polyfills)); ?>"></script>


<?php if(app()->isLocal()): ?>
  <script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php else: ?>
  <script src="<?php echo e(mix('js/manifest.js')); ?>"></script>
  <script src="<?php echo e(mix('js/vendor.js')); ?>"></script>
  <script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php endif; ?>
